export interface IconProps extends React.ComponentProps<'svg'> {
    size?: number;
    color?: string;
}
