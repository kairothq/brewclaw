import { Thumbnail } from "@/components/marketing/thumbnail"

export default function ThumbnailPage() {
  return <Thumbnail />
}
